﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Graphics.Display;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.UI.Xaml.Media.Imaging;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace PictureLibrary
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            MaximizeWindowOnLoad();
            this.InitializeComponent();
            
            
        }
        protected override async void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            this.DataContext = await Helper.GetAllPictures();
        }

        private static void MaximizeWindowOnLoad()
        {

            //var view = DisplayInformation.GetForCurrentView();

            //// Get the screen resolution (APIs available from 14393 onward).
            //var resolution = new Size(view.ScreenWidthInRawPixels, view.ScreenHeightInRawPixels);

            //// Calculate the screen size in effective pixels. 
            //// Note the height of the Windows Taskbar is ignored here since the app will only be given the maxium available size.
            //var scale = view.ResolutionScale == ResolutionScale.Invalid ? 1 : view.RawPixelsPerViewPixel;
            //var bounds = new Size(resolution.Width / scale, resolution.Height / scale);

            //ApplicationView.PreferredLaunchViewSize = new Size(bounds.Width, bounds.Height);
            ApplicationView.PreferredLaunchWindowingMode = ApplicationViewWindowingMode.Maximized;

        }


        private void Home_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Albums_Click(object sender, RoutedEventArgs e)
        {
            MainSplitView.IsPaneOpen = !MainSplitView.IsPaneOpen;

        }

        private async void AddPicture_Click(object sender, RoutedEventArgs e)
        {
            StorageFolder storageFolder = ApplicationData.Current.LocalFolder;

            FileOpenPicker openPicker = new FileOpenPicker();
            openPicker.ViewMode = PickerViewMode.Thumbnail;
            openPicker.SuggestedStartLocation = PickerLocationId.PicturesLibrary;
            openPicker.FileTypeFilter.Add(".jpg");
            openPicker.FileTypeFilter.Add(".png");
            var fileList = await openPicker.PickMultipleFilesAsync();
            if (fileList != null)
            {
                foreach (var file in fileList)
                {
                    var stream = await file.CopyAsync(storageFolder,file.Name, NameCollisionOption.GenerateUniqueName);
                    //var image = new BitmapImage();
                    //image.SetSource(stream);
                    //yourimagelist.Add(image);
                }
            }
            else
            {
                //  
            }

        }

        private async void AddAlbum_Click(object sender, RoutedEventArgs e)
        {
            //if (!AddAlbumContentDialog.IsOpen) { AddAlbumPopup.IsOpen = true; }

            var btn = sender as Button;
            var result = await AddAlbumContentDialog.ShowAsync();
            
        }



        private void AppBarToggleButton_Click(object sender, RoutedEventArgs e)
        {
            FlyoutBase.ShowAttachedFlyout((FrameworkElement)sender);
        }


        private async void AddAlbumContentDialog_PrimaryButtonClick(ContentDialog sender, ContentDialogButtonClickEventArgs args)
        {
            try
            {
                var appFolder = await ApplicationData.Current.LocalFolder.CreateFolderAsync(txtAlbumName.Text, CreationCollisionOption.FailIfExists);

            }
            catch (Exception e)
            {
               
                args.Cancel = true;
                txtError.Text = "Album Name Already Exists!";
            }
        }
    }
}
